package com.pracazaliczeniowa.pracazaliczeniowa;


/*
@SpringBootTest
class PracazaliczeniowaApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/